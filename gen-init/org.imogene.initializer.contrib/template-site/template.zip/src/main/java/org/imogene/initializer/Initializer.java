package org.imogene.initializer;

public interface Initializer {
	
	public void initialize();

}
