package org.imogene.web.shared.proxy.criteria;

import org.imogene.lib.common.criteria.ImogDisjunction;

import com.google.web.bindery.requestfactory.shared.ProxyFor;

@ProxyFor(value=ImogDisjunction.class)
public interface ImogDisjunctionProxy extends ImogJunctionProxy {
	
		
}
