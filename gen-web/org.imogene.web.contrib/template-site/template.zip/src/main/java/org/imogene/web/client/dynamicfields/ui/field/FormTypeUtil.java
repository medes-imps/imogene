package org.imogene.web.client.dynamicfields.ui.field;

import java.util.List;

public interface FormTypeUtil {
	
	
	public List<FormType> getFormTypes();
	
	public List<FormType> getDynamicFieldFormTypes();

}
