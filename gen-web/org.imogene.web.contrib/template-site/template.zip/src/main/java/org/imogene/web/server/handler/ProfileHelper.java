package org.imogene.web.server.handler;

import org.imogene.lib.common.profile.Profile;

public interface ProfileHelper {

	public Profile createProfile();

}
