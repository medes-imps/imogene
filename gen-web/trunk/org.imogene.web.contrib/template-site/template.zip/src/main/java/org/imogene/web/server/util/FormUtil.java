package org.imogene.web.server.util;


public interface FormUtil {	
	
	public String getActorClassName(String shortName);

}
