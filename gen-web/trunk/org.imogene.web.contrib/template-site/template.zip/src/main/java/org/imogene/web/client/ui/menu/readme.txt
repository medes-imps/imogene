theses classes are not used for the moment.
maybe if a menu is implemented in the user interface