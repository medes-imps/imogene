package org.imogene.web.shared.constants;

public class UserActionConstants {
	
	public static final String USERACTION_TYPE_CREATE = "create";
	public static final String USERACTION_TYPE_READ = "read";
	public static final String USERACTION_TYPE_UPDATE = "update";
	public static final String USERACTION_TYPE_DELETE = "delete";

}
