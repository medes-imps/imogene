package org.imogene.lib.common.entity;

public interface CloneFactory {
	
	public Object clone(Object source);

}
