package org.imogene.sync.client.init;

public interface ClientInitializer {

	public void initDatase();

}
