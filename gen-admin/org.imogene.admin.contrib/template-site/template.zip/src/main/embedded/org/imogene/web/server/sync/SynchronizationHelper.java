package org.imogene.web.server.sync;

public interface SynchronizationHelper {

	public void init(String url, String login, String password);

}