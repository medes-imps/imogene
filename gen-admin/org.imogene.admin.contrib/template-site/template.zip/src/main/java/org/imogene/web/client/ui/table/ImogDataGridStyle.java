package org.imogene.web.client.ui.table;

import com.google.gwt.user.cellview.client.DataGrid;

public interface ImogDataGridStyle extends DataGrid.Style{
	
    String IMOG_CSS = "org/imogene/web/client/ui/table/ImogDataGrid.css";

}
