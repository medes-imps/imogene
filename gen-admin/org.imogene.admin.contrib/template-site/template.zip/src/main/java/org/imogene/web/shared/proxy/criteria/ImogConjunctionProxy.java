package org.imogene.web.shared.proxy.criteria;

import org.imogene.lib.common.criteria.ImogConjunction;

import com.google.web.bindery.requestfactory.shared.ProxyFor;

@ProxyFor(value=ImogConjunction.class)
public interface ImogConjunctionProxy extends ImogJunctionProxy {

	
}
