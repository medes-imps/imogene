package org.imogene.notif.aop;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;
import org.imogene.lib.common.constants.UserActionConstants;
import org.imogene.lib.common.dao.GenericDao;
import org.imogene.lib.common.entity.CloneFactory;
import org.imogene.lib.common.entity.ImogActor;
import org.imogene.lib.common.entity.ImogBean;
import org.imogene.lib.common.useraction.UserAction;
import org.imogene.web.server.util.HttpSessionUtil;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author MEDES/IMPS
 */
public class NotificationSaveInterceptor implements AfterReturningAdvice {

	private static final Logger logger = Logger.getLogger(NotificationSaveInterceptor.class);

	private String notifierHost = "http://localhost:8080/DiabsatNotif";

	private GenericDao genericDao;

	private CloneFactory cloneFactory;

	/**
	 * Notify about the entity modification/creation
	 */
	@Override
	public void afterReturning(Object result, Method method, Object[] args, Object target) throws Throwable {
		try {
			handleAction(method, args, result);
		} catch (Throwable t) {
			// No matter what happened we should not stop execution of a query for that
		}
	}

	/**
	 * @param method
	 * @param args
	 * @param result
	 */
	@Transactional
	private void handleAction(Method method, Object[] args, Object result) {
		if (method.getName().equals("saveOrUpdate") || method.getName().equals("merge")) {
			handleSaveAction(args);
		} else if (method.getName().equals("load") && args != null && args.length == 1 && args[0] instanceof String) {
			handleViewAction(result);
		} else if (method.getName().equals("delete")) {
			// not called anymore by new way of managing deleted entities
			handleDeleteAction(args);
		}
	}

	/**
	 * Handle the saveOrUpdate method
	 * @param args arguments of the method
	 */
	private void handleSaveAction(Object[] args) {

		ImogBean bean = (ImogBean) args[0];
		boolean isNew = (Boolean) args[1];

		String idFormulaire = bean.getId();
		String className = bean.getClass().getName();
		String typeFormulaire = bean.getClass().getSimpleName();
		String typeAction = null;
		
		if(isNew) {
			if(bean.getDeleted()!=null)
				// a deleted entity is saved as new and deleted
				typeAction = UserActionConstants.USERACTION_TYPE_DELETE;
			else
				typeAction = UserActionConstants.USERACTION_TYPE_CREATE;
		}
		else
			typeAction = UserActionConstants.USERACTION_TYPE_UPDATE;

		saveAction(typeAction, typeFormulaire, idFormulaire);

		try {
			cloneEntity(bean);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		sendToNotifier(className, typeAction, idFormulaire);
	}

	/**
	 * @param args
	 * @param result
	 */
	private void handleViewAction(Object result) {

		if (result != null) {
			ImogBean bean = (ImogBean) result;
			String idFormulaire = bean.getId();
			String typeFormulaire = bean.getClass().getSimpleName();
			String typeAction = UserActionConstants.USERACTION_TYPE_READ;

			saveAction(typeAction, typeFormulaire, idFormulaire);
		}
	}

	/**
	 * @param args
	 */
	private void handleDeleteAction(Object[] args) {

		ImogBean bean = (ImogBean) args[0];
		String idFormulaire = bean.getId();
		String typeFormulaire = bean.getClass().getSimpleName();
		String typeAction = UserActionConstants.USERACTION_TYPE_DELETE;

		saveAction(typeAction, typeFormulaire, idFormulaire);
	}

	private void cloneEntity(Object source) {
		if (source != null) {
			Object clone = cloneFactory.clone(source);
			if (clone != null)
				genericDao.saveOrUpdate(clone);
		}
	}

	/**
	 * Notify the notifier by http.
	 * @param type the card type
	 * @param operation the operation on the card
	 * @param id the card id
	 */
	private void sendToNotifier(final String type, final String operation, final String id) {

		/* thread the notification process */
		new Thread() {
			@Override
			public void run() {

				HttpClient client = new HttpClient();
				String uri = notifierHost + "?" + "type=" + type + "&op=" + operation + "&id=" + id;
				logger.debug("Notifier URI : " + uri);
				GetMethod method = new GetMethod(uri);
				try {
					client.executeMethod(method);
				} catch (Exception ex) {
					logger.error(ex.getMessage());
				}

			}
		}.start();
	}

	/**
	 * @param typeAction
	 * @param typeFormulaire
	 * @param idFormulaire
	 */
	private void saveAction(String actionType, String form, String formId) {

		UserAction action = new UserAction();
		action.setId(UUID.randomUUID().toString());
		action.setActionDate(new Date(System.currentTimeMillis()));
		ImogActor actor = HttpSessionUtil.getCurrentUser();
		action.setUserId(actor.getId());
		action.setActionType(actionType);
		action.setFormType(form);
		action.setFormId(formId);

		genericDao.saveOrUpdate(action);
	}

	/**
	 * Setter for bean injection
	 * @param notifier the notifier URL
	 */
	public void setNotifierUrl(String notifier) {
		notifierHost = notifier;
	}

	/**
	 * Setter for bean injection
	 * @param dao
	 */
	public void setGenericDao(GenericDao dao) {
		genericDao = dao;
	}

	/**
	 * Setter for bean injection
	 * @param cloneFactory
	 */
	public void setCloneFactory(CloneFactory cloneFactory) {
		this.cloneFactory = cloneFactory;
	}

}
