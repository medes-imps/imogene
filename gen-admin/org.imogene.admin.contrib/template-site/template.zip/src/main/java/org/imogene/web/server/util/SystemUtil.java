package org.imogene.web.server.util;

public interface SystemUtil {

	public long getCurrentTimeMillis();

	public String getTerminal();

}
