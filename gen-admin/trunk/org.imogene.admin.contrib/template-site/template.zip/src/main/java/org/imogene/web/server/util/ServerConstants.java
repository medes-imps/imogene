package org.imogene.web.server.util;

public class ServerConstants {

	/** */
	public static String SESSION_USER = "session_user";
	
	/** */
	public static String SESSION_LAST_LOGIN ="session_last_login";
	
	/** */
	public static String SESSION_USER_ID = "session_user_id";
}
