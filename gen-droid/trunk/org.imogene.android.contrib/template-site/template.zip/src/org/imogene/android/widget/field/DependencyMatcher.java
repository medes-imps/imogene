package org.imogene.android.widget.field;

interface DependencyMatcher {
	
	boolean matchesDependencyValue(String dependencyValue);

}
